#!/usr/bin/env python3
"""Render template-art.html + content/<lang>.json -> public/[lang/]<slug>/index.html
Copy of build-art/render_art.py for article 2. Differences: SLUG, dates, image."""
import json, os, re, sys
from bs4 import BeautifulSoup
import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_HERE)
BUILD = _HERE
PUB = _os.path.join(_ROOT, 'public')
SLUG = 'colmar-vs-strasbourg-christmas'
BASE = 'https://colmartour.com'
DATE = '2026-09-29'
IMAGE = 'tile-christmas-market.webp'
LANGS = {
 'en': dict(locale='en_US'), 'fr': dict(locale='fr_FR'), 'de': dict(locale='de_DE'),
 'es': dict(locale='es_ES'), 'it': dict(locale='it_IT'), 'pt': dict(locale='pt_PT'),
 'pl': dict(locale='pl_PL'), 'ru': dict(locale='ru_RU'),
}
ORDER = ['en', 'fr', 'de', 'es', 'it', 'pt', 'pl', 'ru']
KEEP = re.compile(r'^/(img/|favicon|robots|sitemap|llms|en|fr|de|es|it|pt|pl|ru)(/|\.|$)')
tpl = open(f'{BUILD}/template-art.html', encoding='utf-8').read()
en = json.load(open(f'{BUILD}/content/en.json', encoding='utf-8'))
def langnav(cur):
    out = []
    for l in ORDER:
        href = f'/{SLUG}/' if l == 'en' else f'/{l}/{SLUG}/'
        on = ' class="on"' if l == cur else ''
        out.append(f'<a{on} href="{href}">{l.upper()}</a>')
    return '<nav class="lang">' + ''.join(out) + '</nav>'
def prefix_links(html, lang):
    if lang == 'en':
        return html
    def rep(m):
        q, path = m.group(1), m.group(2)
        if KEEP.match(path):
            return m.group(0)
        if path == '/':
            return f'href={q}/{lang}/{q}'
        return f'href={q}/{lang}{path}{q}'
    return re.sub(r'href=(["\'])(/[^"\']*)\1', rep, html)
def jsonld(soup, lang):
    url = f'{BASE}/{SLUG}/' if lang == 'en' else f'{BASE}/{lang}/{SLUG}/'
    h1 = soup.find('h1').get_text(strip=True)
    desc = soup.find('meta', attrs={'name': 'description'})['content']
    faq = []
    for d in soup.select('.faq details'):
        q = d.find('summary').get_text(strip=True)
        a = ' '.join(p.get_text(' ', strip=True) for p in d.find_all('p'))
        faq.append({"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}})
    crumb_home = soup.select_one('.crumb a')
    graph = [
     {"@type": "Article", "@id": url + "#article", "headline": h1, "description": desc, "inLanguage": lang,
      "image": f"{BASE}/img/{IMAGE}", "datePublished": DATE, "dateModified": DATE,
      "author": {"@type": "Person", "name": "Eugene", "url": BASE + ('/' if lang == 'en' else f'/{lang}/')},
      "publisher": {"@type": "Organization", "name": "ColmarTour", "logo": {"@type": "ImageObject", "url": f"{BASE}/img/logo.webp"}},
      "mainEntityOfPage": {"@type": "WebPage", "@id": url}},
     {"@type": "FAQPage", "@id": url + "#faq", "mainEntity": faq},
     {"@type": "BreadcrumbList", "@id": url + "#crumbs", "itemListElement": [
      {"@type": "ListItem", "position": 1, "name": crumb_home.get_text(strip=True) if crumb_home else "Colmar",
       "item": BASE + ('/' if lang == 'en' else f'/{lang}/')},
      {"@type": "ListItem", "position": 2, "name": h1, "item": url}]},
    ]
    return json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False, indent=1)
def render(lang):
    data = json.load(open(f'{BUILD}/content/{lang}.json', encoding='utf-8'))
    out = tpl
    missing = []
    for k in en:
        v = data.get(k)
        if isinstance(v, dict):
            v = v.get('loc') or v.get('en')
        if not v:
            missing.append(k); v = en[k]['en']
        out = out.replace('{{%s}}' % k, v)
    url = f'{BASE}/{SLUG}/' if lang == 'en' else f'{BASE}/{lang}/{SLUG}/'
    out = (out.replace('{{LANG}}', lang).replace('{{OG_LOCALE}}', LANGS[lang]['locale'])
              .replace('{{CANONICAL}}', url).replace('{{LANGNAV}}', '@@LANGNAV@@'))
    out = prefix_links(out, lang)
    out = out.replace('@@LANGNAV@@', langnav(lang))
    if lang != 'en':
        out = out.replace('src="../img/', 'src="../../img/')
    soup = BeautifulSoup(out, 'html.parser')
    tag = soup.new_tag('script', type='application/ld+json')
    tag.string = jsonld(soup, lang)
    soup.find('body').append(tag)
    out = str(soup)
    d = f'{PUB}/{SLUG}' if lang == 'en' else f'{PUB}/{lang}/{SLUG}'
    os.makedirs(d, exist_ok=True)
    open(f'{d}/index.html', 'w', encoding='utf-8').write(out)
    left = re.findall(r'\{\{[A-Z0-9_]+\}\}', out)
    return len(missing), set(left)
if __name__ == '__main__':
    for l in (sys.argv[1:] or ORDER):
        n, left = render(l)
        print(f'{l}: {"OK" if not n and not left else "CHECK"} missing={n} unresolved={left or "-"}')
